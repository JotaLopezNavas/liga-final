<template>
  <div id="contact">
    <div id="container">
      <div id="pageheader">
        <h1>Contact</h1>
      </div>
      <div id="bodycontent">
        <p>
          Please email us at
          <a href="mailto:nysl@chisoccer.org">nysl@chisoccer.org</a>
        </p>

        <p>We will reply to your email as soon as we can.</p>
      </div>
    </div>
  </div>
</template>