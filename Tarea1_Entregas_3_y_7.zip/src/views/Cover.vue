<template>
    <div id="Cover">
        <router-link to="/home"><img src="../assets/image/logo.gif" alt=""></router-link>
    </div>
</template>