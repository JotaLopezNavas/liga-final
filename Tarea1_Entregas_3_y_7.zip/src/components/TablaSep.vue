    <template>
    <div id="tabla">
               <table class="table table-bordered">
                    <tr>
                      <th colspan="4" id="sept">SEPTEMBER</th>
                    <tr>
                    <th>Date</th>
                    <th>Teams</th>
                    <th>Location</th>
                    <th>Times</th>
                    </tr>
                    <tr>
                    <td rowspan="2">9/01</td>
                    <td> <img src="../assets/icon/G1.png" alt="icono" class="icono">U1 and U4<img src="../assets/icon/G4.png" alt="icono" class="icono"></td>
                    <td>AJ Katzenmaier</td>
                    <td>9:30 a.m.</td>
                    </tr>
                    <tr>
                    <td><img src="../assets/icon/G3.png" alt="icono" class="icono">U3 and U2<img src="../assets/icon/G2.png" alt="icono" class="icono"></td>
                    <td>Greenbay</td>
                    <td>1:00 p.m.</td>
                    </tr>
                    <tr>
                    <td rowspan="2">9/08</td>
                    <td><img src="../assets/icon/G5.png" alt="icono" class="icono">U5 and U6<img src="../assets/icon/G6.png" alt="icono" class="icono"></td>
                    <td>Howard A Yeager</td>
                    <td>9:30 a.m.</td>
                    </tr>
                    <tr>
                    <td><img src="../assets/icon/G6.png" alt="icono" class="icono">U6 and U1<img src="../assets/icon/G1.png" alt="icono" class="icono"></td>
                    <td>Marjorie P Hart</td>
                    <td>1:00 p.m.</td>
                    <tr>
                    <td rowspan="2">9/15</td>
                    <td><img src="../assets/icon/G2.png" alt="icono" class="icono">U2 and U4<img src="../assets/icon/G4.png" alt="icono" class="icono"></td>
                    <td>North</td>
                    <td>9:30 a.m.</td>
                    </tr>
                    <tr>
                    <td><img src="../assets/icon/G3.png" alt="icono" class="icono">U3 and U5<img src="../assets/icon/G5.png" alt="icono" class="icono"></td>
                    <td>AJ Katzenmaier</td>
                    <td>1:00 p.m.</td>
                    <tr>
                    <td rowspan="2">9/22</td>
                    <td><img src="../assets/icon/G1.png" alt="icono" class="icono">U1 and U3<img src="../assets/icon/G3.png" alt="icono" class="icono"></td>
                    <td>South</td>
                    <td>9:30 a.m.</td>
                    </tr>
                    <tr>
                    <td><img src="../assets/icon/G2.png" alt="icono" class="icono">U2 and U6<img src="../assets/icon/G6.png" alt="icono" class="icono"></td>
                    <td>Howard A Yeager</td>
                    <td>1:00 p.m.</td>
                    <tr>
                    <td>9/29</td>
                    <td><img src="../assets/icon/G4.png" alt="icono" class="icono">U4 and U5<img src="../assets/icon/G5.png" alt="icono" class="icono"></td>
                    <td>Greenbay</td>
                    <td>9:30 a.m.</td>
                    </tr>
              </table>
      </div>
</template>