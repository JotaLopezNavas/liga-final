    <template>
    <div id="tabla">
       <table class="table table-bordered">
              <tr>
                  <th colspan="4" id="oct">OCTOBER</th>
              <tr>
            <tr>
              <th>Date</th>
              <th>Teams</th>
              <th>Location</th>
              <th>Times</th>
            </tr>
            <tr>
              <td rowspan="2">10/06</td>
              <td><img src="../assets/icon/G2.png" alt="icono" class="icono">U2 and U5<img src="../assets/icon/G5.png" alt="icono" class="icono"></td>
              <td>Marjorie P Hart</td>
              <td>9:30 a.m.</td>
            </tr>
            <tr>
              <td><img src="../assets/icon/G1.png" alt="icono" class="icono">U1 and U6<img src="../assets/icon/G6.png" alt="icono" class="icono"></td>
              <td>South</td>
              <td>1:00 p.m.</td>
            </tr>
            <tr>
              <td rowspan="2">10/08</td>
              <td><img src="../assets/icon/G3.png" alt="icono" class="icono">U3 and U4<img src="../assets/icon/G4.png" alt="icono" class="icono"></td>
              <td>Howard A Yeager</td>
              <td>9:30 a.m.</td>
            </tr>
            <tr>
              <td><img src="../assets/icon/G5.png" alt="icono" class="icono">U5 and U1<img src="../assets/icon/G1.png" alt="icono" class="icono"></td>
              <td>Greenbay</td>
              <td>1:00 p.m.</td>
          <tr>
              <td rowspan="2">10/20</td>
              <td><img src="../assets/icon/G6.png" alt="icono" class="icono">U6 and U3<img src="../assets/icon/G3.png" alt="icono" class="icono"></td>
              <td>North</td>
              <td>9:30 a.m.</td>
            </tr>
            <tr>
              <td><img src="../assets/icon/G2.png" alt="icono" class="icono">U2 and U4<img src="../assets/icon/G4.png" alt="icono" class="icono"></td>
              <td>Marjorie P Hart</td>
              <td>1:00 p.m.</td>
            <tr>
              <td rowspan="2">10/27</td>
              <td><img src="../assets/icon/G3.png" alt="icono" class="icono">U3 and U1<img src="../assets/icon/G1.png" alt="icono" class="icono"></td>
              <td>AJ Katzenmaier</td>
              <td>9:30 a.m.</td>
            </tr>
            <tr>
              <td><img src="../assets/icon/G5.png" alt="icono" class="icono">U5 and U6<img src="../assets/icon/G6.png" alt="icono" class="icono"></td>
              <td>Howard A Yeager</td>
              <td>1:00 p.m.</td>
            </tr>
          </table>
    </div>
</template>